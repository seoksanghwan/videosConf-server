module.exports = {
  'secret': 'SeCrEtKeYfOrHaShInG',
  'mongodbUri': 'mongodb://admin:tlshqn123@ds111113.mlab.com:11113/helloalgoalgo'
}